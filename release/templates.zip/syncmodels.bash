#!/bin/bash

cp models/rest.profile.uml templates/empty_model
cp models/raml.profile.uml templates/empty_model
cp models/rest.profile.css templates/empty_model
cp models/empty.di templates/empty_model
cp models/empty.notation templates/empty_model
cp models/empty.uml templates/empty_model
cp models/rest.profile.uml uml2raml/src/test/resources/uml
cp models/raml.profile.uml uml2raml/src/test/resources/uml
cp models/rest.profile.css uml2raml/src/test/resources/uml

