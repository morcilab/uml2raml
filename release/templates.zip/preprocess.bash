#!/bin/bash

anchor="<a name='" _anchor="'></a>" mo/mo README.md.mo > README.md

